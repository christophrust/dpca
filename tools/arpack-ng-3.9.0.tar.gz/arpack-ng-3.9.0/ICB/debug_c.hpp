#ifndef __DEBUG_C_HPP__
#define __DEBUG_C_HPP__

#include "arpackdef.h"

extern "C" void debug_c(a_int logfil_c, a_int ndigit_c, a_int mgetv0_c,
                        a_int msaupd_c, a_int msaup2_c, a_int msaitr_c, a_int mseigt_c, a_int msapps_c, a_int msgets_c, a_int mseupd_c,
                        a_int mnaupd_c, a_int mnaup2_c, a_int mnaitr_c, a_int mneigh_c, a_int mnapps_c, a_int mngets_c, a_int mneupd_c,
                        a_int mcaupd_c, a_int mcaup2_c, a_int mcaitr_c, a_int mceigh_c, a_int mcapps_c, a_int mcgets_c, a_int mceupd_c);

#endif
